

<?php
$dsn="mysql:host=localhost;dbname=doctor_finder";
$user="root";
$pass="";
$dbh = new PDO($dsn,$user,$pass);
