<!DOCTYPE html>
<html>
<head>
	<title>footer</title>

	<style type="text/css" media="screen">

		*{
			padding: 0px;
			margin: 0px;

		}
		.inner-footer{
			text-align: center;
			/* height: 20px; */
			width: 100%;
			background-color: black;
			color: #e61e28;
			padding: 10px 0%;
			padding-top: 0px;
			font-family: "Montserrat",sans-serif; 
			font-size: 12px;
		
  			
		}

		
	</style>

</head>
<body>

	<footer class="footer">
		<div class="inner-footer">
			<br>
			
			 &copy <?php echo date("Y");?> - Doctor finder.
			
			
		</div>

		
	</footer>

</body>
</html>