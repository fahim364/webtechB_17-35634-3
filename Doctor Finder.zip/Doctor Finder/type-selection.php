<?php 
	include('include/nav.php');
 ?>




<!-- ======================================================? -->


 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Registration </title>  
          

    
            <style type="text/css" media="screen">

              .button{
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        margin-left: 50px;
      

        
      }
      .button1 {
        background-color: #009184;
        font-family: "Montserrat",sans-serif;
 
      }

      .font{
        font-family: "Montserrat",sans-serif;
      }
              
      </style>
      </head>  

     <body>
     <div  class="mainbody">

     
     
      <br>
      <br>
      <br>

    


      <div align=center>
         <br>
   
    <h1 class="font"> User Type </h1>
     
     <br>
     <br>
     <br>
       
      <a href="register.php"><button class="button button1 bg-primary" >User</button></a> 
      <a href="doctor_registration.php"><button class="button button1 bg-primary" >Doctor </button></a> 
     
     
    
      </div>

  
   
    
     
   
</div>
 <!-- ========================End Dashbord main body====================== -->


         
         
           <br> 
           <br> 
           <br> 
           <br> 
           <br> 
           <br> 
           <br> 
           <br> 
           <br> 
           <br> 
           <br> 
           <br> 
           <br> 
           <br> 
           <br> 
              
      </body>  

 </html>  



 <?php  
 include('include/Hfooter.php')
 ?>